import React from 'react';
import './App.css';

function App() {
  return ( 
    
  <div className="menu">   
<switch class="nav">
<form >
<h1 class="text">TermMonitor</h1>

<input type="search" placeholder="enter a keyword"/>
<button>submit -></button>
 </form></switch>
 <center><h3>Add Another keyword  <tt > 1/3 </tt>UPGRADE</h3></center>
 <section class="search"><input type="search" placeholder="Enter your filters here"/></section>
<li class="one">Add keywords</li>
<li>Matches</li>
<li>Manage resources</li>
<li>integration</li>
<li>alerts</li>
<li>settings</li>
   </div >
  );
}

export default App;
