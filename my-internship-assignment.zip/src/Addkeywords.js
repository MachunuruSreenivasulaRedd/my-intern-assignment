import React  from 'react';
function Addkeywords(){
  return(
    <div className='addkeywords'>
    <h1>add keywords through this button</h1>
    </div>
  );
}
export default Addkeywords;